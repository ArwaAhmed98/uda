#----------------------------------------------------------------------------#
# Imports
#----------------------------------------------------------------------------#

import json
import dateutil.parser
import babel
from flask import Flask, render_template, request, Response, flash, redirect, url_for
from flask_moment import Moment
from flask_sqlalchemy import SQLAlchemy
import logging
from logging import Formatter, FileHandler
from flask_wtf import Form
from forms import *
from sqlalchemy_utils import create_database, database_exists
import config
from models import db, Artist, Venue, Show
import traceback
from flask_migrate import Migrate, MigrateCommand
from flask_script import Manager
from sqlalchemy.orm.exc import NoResultFound
import sys
#----------------------------------------------------------------------------#
# App Config.
#----------------------------------------------------------------------------#

app = Flask(__name__)
app.config.from_object('config')
db.init_app(app) #  for the migrations
migrate = Migrate(app, db)

#----------------------------------------------------------------------------#
# Filters.
#----------------------------------------------------------------------------#


def format_datetime(value, format='medium'):
    date = dateutil.parser.parse(value)
    if format == 'full':
        format = "EEEE MMMM, d, y 'at' h:mma"
    elif format == 'medium':
        format = "EE MM, dd, y h:mma"
    return babel.dates.format_datetime(date, format)


app.jinja_env.filters['datetime'] = format_datetime

#----------------------------------------------------------------------------#
# Controllers.
#----------------------------------------------------------------------------#


@app.route('/')
def index():
    return render_template('pages/home.html')


#  Venues
#  ----------------------------------------------------------------

@app.route('/venues')
def venues():
    filtered_stat = Venue.query.distinct(Venue.city, Venue.state).all()
    data = [x.filter_on_city_state for x in filtered_stat]
    print(data)

    return render_template('pages/venues.html', areas=data)


@app.route('/venues/search', methods=['POST'])
def search_venues():
    search_term = request.form.get('search_term', None)
    x = Venue.query.filter(
    Venue.name.ilike("%{}%".format(search_term))).all()
    counted_venues = len(x)
    response = {
        "count": counted_venues,
        "data": [v.serialize for v in x]
    }
    return render_template('pages/search_venues.html', results=response, search_term=request.form.get('search_term', ''))


@app.route('/venues/<int:venue_id>')
def show_venue(venue_id):
    
        
    x= Venue.query.filter(Venue.id == venue_id).one_or_none()
    if x is None :
        
        abort(404)
    
# """  
# FROM DOCUMENTION OF SQLAlchemy
# 
# method sqlalchemy.orm.query.Query.one_or_none()

#     Return at most one result or raise an exception.

#     Returns None if the query selects no rows. Raises sqlalchemy.orm.exc.MultipleResultsFound 
#     if multiple object identities are returned, or if multiple rows are returned for a query that 
#     returns only scalar values as opposed to full identity-mapped entities.

#     Calling Query.one_or_none() results in an execution of the underlying query."""
    # data = [v.serialize_with_upcoming_shows_count for v in venues][0]
    data = x.serialize
    return render_template('pages/show_venue.html', venue=data)


#  Create Venue
#  ----------------------------------------------------------------


@app.route('/venues/create', methods=['GET'])
def create_venue_form():
    new_form = VenueForm()
    return render_template('forms/new_venue.html', form=new_form)


@app.route('/venues/create', methods=['POST'])
def create_venue_submission():
    venue_form = VenueForm(request.form)

    try:
        new_data = Venue(
            name=venue_form.name.data,
            genres=','.join(venue_form.genres.data),
            address=venue_form.address.data,
            city=venue_form.city.data,
            state=venue_form.state.data,
            phone=venue_form.phone.data,
            facebook_link=venue_form.facebook_link.data,
            image_link=venue_form.image_link.data)

        new_data.add()
        # on successful db insert, flash success
        flash('Venue ' + request.form['name'] + ' was successfully listed!')
    except Exception as e:
        flash('An error occurred  Venue with the following name could not be added ' + request.form['name'] + ' could not be listed.')
        traceback.print_exc()

    return render_template('pages/home.html')


@app.route('/venues/<venue_id>', methods=['DELETE'])
def delete_venue(venue_id):
    try:
        ven_to_be_deleted_from_the_form = Venue.query.filter(Venue.id == venue_id).one()
        ven_to_be_deleted_from_the_form.delete()
        flask("Venue {0} has been deleted successfully".format(
            ven_to_be_deleted_from_the_form[0]['name']))
    except NoResultFound:
        abort(404)

#  Artists
#  ----------------------------------------------------------------
@app.route('/artists')
def artists():
    artists = Artist.query.all()
    data = [iterator1.serialize for iterator1 in artists]
    return render_template('pages/artists.html', artists=data)


@app.route('/artists/search', methods=['POST'])
def search_artists():
    search_term = request.form.get('search_term', None)
    x = Artist.query.filter(
        Artist.name.ilike("%{}%".format(search_term))).all()
    no_of_artists = len(x)
    response = {
        "count": no_of_artists,
        "data": [a.serialize for a in x]
    }
    return render_template('pages/search_artists.html', results=response, search_term=request.form.get('search_term', ''))


@app.route('/artists/<int:artist_id>')
def show_artist(artist_id):
    try:
        
        artist = Artist.query.filter(Artist.id == artist_id).one_or_none()
        
    except:
       
        abort(404)

    data = artist.serialize

    return render_template('pages/show_artist.html', artist=data)

#  Update
#  ----------------------------------------------------------------
@app.route('/artists/<int:artist_id>/edit', methods=['GET'])
def edit_artist(artist_id):
    artist_form = ArtistForm()

    artist_is_gonna_update = Artist.query.filter(
        Artist.id == artist_id).one_or_none()
    if artist_is_gonna_update is None:
        abort(404)

    artist = artist_is_gonna_update.serialize
    form = ArtistForm(data=artist)
    return render_template('forms/edit_artist.html', form=form, artist=artist)


@app.route('/artists/<int:artist_id>/edit', methods=['POST'])
def edit_artist_submission(artist_id):
    form = ArtistForm(request.form)
    try:
        artist = Artist.query.filter_by(id=artist_id).one()
        artist.name = form.name.data,
        artist.genres = json.dumps(form.genres.data),  # array json
        artist.city = form.city.data,
        artist.state = form.state.data,
        artist.phone = form.phone.data,
        artist.facebook_link = form.facebook_link.data,
        artist.image_link = form.image_link.data,
        artist.update()
        # on successful db insert, flash success
        flash('Artist ' + request.form['name'] + ' was successfully updated!')
    except Exception as e:
        flash('An error occurred. Artist you have entered as follow ' +
              request.form['name'] + ' could not be updated.')
    return redirect(url_for('show_artist', artist_id=artist_id))


@app.route('/venues/<int:venue_id>/edit', methods=['GET'])
def edit_venue(venue_id):
    venue_form = VenueForm()

    venue_is_gonna_update = Venue.query.filter(Venue.id == venue_id).one_or_none()
    if venue_is_gonna_update is None:
        abort(404)

    venue = venue_is_gonna_update.serialize
    form = VenueForm(data=venue)
    return render_template('forms/edit_venue.html', form=form, venue=artist)


@app.route('/venues/<int:venue_id>/edit', methods=['POST'])
def edit_venue_submission(venue_id):  
    form = VenueForm(request.form)
    try:
        venue = Venue.query.filter(Venue.id==venue_id).one()
        venue.name = form.name.data,
        venue.address = form.address.data,
        venue.genres = '.'.join(form.genres.data),  # array json
        venue.city = form.city.data,
        venue.state = form.state.data,
        venue.phone = form.phone.data,
        venue.facebook_link = form.facebook_link.data,
        venue.image_link = form.image_link.data,
        venue.update()
        # on successful db insert, flash success
        flash('Venue ' + request.form['name'] + ' was successfully updated!')
    except Exception as e:
        flash('An error occurred. Venue you entered as follow  ' +
              request.form['name'] + ' could not be updated.')

    return redirect(url_for('show_venue', venue_id=venue_id))

#  Create Artist
#  ----------------------------------------------------------------


@app.route('/artists/create', methods=['GET'])
def create_artist_form():
    form = ArtistForm()
    return render_template('forms/new_artist.html', form=form)


@app.route('/artists/create', methods=['POST'])
def create_artist_submission():
    y = ArtistForm(request.form)

    try:
        new_data= Artist(
            name=y.name.data,
            genres=','.join(y.genres.data),
            address=y.address.data,
            city=y.city.data,
            state=y.state.data,
            phone=y.phone.data,
            facebook_link=y.facebook_link.data,
            image_link=y.image_link.data)

        new_data.add()
        # on successful db insert, flash success
        flash('Artist ' + request.form['name'] + ' was successfully listed!')
    except Exception as e:
        flash('An error occurred. Artist  you entered as follow' +
              request.form['name'] + ' could not be listed.')

    return render_template('pages/home.html')


#  Shows
#  ----------------------------------------------------------------

@app.route('/shows')
def shows():
    shows = Show.query.all()
    data = [iterator2.serialize for iterator2 in shows]
    print(data)
    return render_template('pages/shows.html', shows=data)


@app.route('/shows/create')
def create_shows():
    # renders form. do not touch.
    form = ShowForm()
    return render_template('forms/new_show.html', form=form)



@app.route('/shows/create', methods=['POST'])
def create_show_submission():
    return render_template('pages/home.html')
    

@app.errorhandler(404)
def not_found_error(error):
    return render_template('errors/404.html'), 404


@app.errorhandler(500)
def server_error(error):
    return render_template('errors/500.html'), 500


if not app.debug:
    file_handler = FileHandler('error.log')
    file_handler.setFormatter(
        Formatter(
            '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]')
    )
    app.logger.setLevel(logging.INFO)
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)
    app.logger.info('errors')

#----------------------------------------------------------------------------#
# Launch.
#----------------------------------------------------------------------------#

# Default port:
if __name__ == '__main__':
    manager.run()

# Or specify port manually:
'''
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
'''
